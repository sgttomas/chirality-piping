---
doc_id: OPS-INIT
doc_kind: governance.bootstrap
status: draft
created: 2026-04-30
---

# INIT — OpenPipeStress Agent Bootstrap

OpenPipeStress is a free and open-source, code-neutral piping stress analysis project. The software shall implement open analytical mechanics for global piping flexibility/stress analysis while requiring users to supply code-specific and proprietary engineering data.

All agentic development work must preserve four boundaries:

1. **Open mechanics vs. protected standards data** — public code may implement mechanics and workflows; protected code tables, text, examples, and proprietary values are not public project content.
2. **Mechanics solve vs. user rule check** — a solved model is not the same thing as a code check.
3. **User rule check vs. professional approval** — software output is decision support until a competent human accepts it for project use.
4. **Global centerline analysis vs. local FEA** — routine pipe stress analysis uses a 3D line-element/frame model; shell/solid FEA is a specialized local handoff.

## Required reading order

1. `DIRECTIVE.md` — founding intent and stop rules.
2. `CONTRACT.md` — invariant catalog.
3. `TYPES.md` — vocabulary, identifiers, statuses, and domain terms.
4. `SPEC.md` — technical architecture and implementation mechanics.
5. `IP_AND_DATA_BOUNDARY.md` — public/private data boundary.
6. `VALIDATION_STRATEGY.md` — verification and release-quality expectations.
7. `AGENTIC_DEVELOPMENT_WORKFLOW.md` — how agents execute deliverables.
8. `_Decomposition/SOFTWARE_DECOMP.md` — current package/deliverable working surface.
9. `_Registers/*.csv` — machine-readable scope, deliverable, and context-budget registers.

## Agent rule

Unknown engineering values become `TBD`. Suspected protected data is quarantined. Conflicts are surfaced. No agent may claim certification, code compliance, approval, sealing, or professional reliance.

## Next step

After reading these files, select one `DEL-XX-YY` deliverable from `_Registers/Deliverables.csv`, prepare a sealed context, and execute only that deliverable.
